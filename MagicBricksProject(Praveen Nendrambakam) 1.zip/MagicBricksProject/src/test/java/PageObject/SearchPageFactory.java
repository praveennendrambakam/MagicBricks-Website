package PageObject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import Config.Screenshot;

public class SearchPageFactory {
	WebDriver driver = null;
	private Actions actions;
	Screenshot ss;

	// marks a field on the Page Object for locating the WebElement or a list of
	// WebElements.

	@FindBy(xpath = "//div[@id='tabRENT']")
	WebElement Rent;
	@FindBy(xpath = "//div[@class='mb-search__tag-t']")
	WebElement Value;
	@FindBy(xpath = "//div[@class=\'mb-search__tag-close\']")
	WebElement cross;
	@FindBy(xpath = "//input[@class='mb-search__input']")
	WebElement location;
	@FindBy(xpath = "//div[@onclick='selectSearch(\"Mumbai\",4320,4320,\"city\")']")
	WebElement Value2;
	@FindBy(xpath = "//div[@onclick=\'showPropertyDropDown(event, this);fireSearchBoxClickedGTM();\']")
	WebElement Flat;
	@FindBy(xpath = "//div[text()='Residential']")
	WebElement Residential;
	@FindBy(xpath = "//div[@onclick=\'openPropertyType(this);\']")
	WebElement Commercial;
	@FindBy(xpath = "//div[text()='Other Property Types']")
	WebElement OtherPropertyTypes;
	@FindBy(xpath = "//span[@class='buy_budget_lbl']")
	WebElement Budget;
	@FindBy(xpath = "//input[@id='budgetMin']")
	WebElement minPrice;
	@FindBy(xpath = "//input[@id='budgetMax']")
	WebElement maxPrice;
	@FindBy(xpath = "//div[@class='mb-search__btn']")
	WebElement search;
	@FindBy(xpath = "//span[@class='mb-srp__action--btn medium btn-red']")
	WebElement ContactAgent;
	@FindBy(xpath = "//input[@id='userName']")
	WebElement Name;
	@FindBy(xpath = "//a[@class=\"mb-header__main__logo__link\"]")
	WebElement logo;

	public SearchPageFactory(WebDriver driver) {
		this.driver = driver;
		this.actions = new Actions(driver);
		PageFactory.initElements(driver, this);
		ss = new Screenshot(driver);
	}

	public void searchUsingLocation() throws AWTException, InterruptedException {

		// Actions automating mouse and keyboard events in web applications
		Actions action = new Actions(driver);
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2));
		wait.until(ExpectedConditions.visibilityOf(Rent));
		action.moveToElement(Rent);
		wait.until(ExpectedConditions.elementToBeClickable(Rent)).click();

		Thread.sleep(2000);
		location.click();
		Value.click();
		cross.click();
		location.sendKeys("Mumbai");
		Assert.assertTrue(location.isDisplayed());
		Value2.click();
		Flat.click();
		Commercial.click();
		OtherPropertyTypes.click();
		Budget.click();
		minPrice.sendKeys("50000");
		maxPrice.click();
		maxPrice.sendKeys("85000");
		search.click();
		Thread.sleep(1000);

		// Robots is a programmable machine that can complete a task
		Robot robot = new Robot();
		robot.mouseMove(150, 150);
		Thread.sleep(3000);
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

		robot.mouseMove(539, 260);
		Thread.sleep(3000);
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

		// This screenshot shows the output of the program under certain conditions.
		ss.captureScreenshot("TestCase1"); // Test Case-2 Screenshot Capturing

	}
}