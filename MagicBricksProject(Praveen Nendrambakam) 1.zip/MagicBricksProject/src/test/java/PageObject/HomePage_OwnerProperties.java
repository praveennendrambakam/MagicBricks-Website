package PageObject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.time.Duration;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import Config.Screenshot;

public class HomePage_OwnerProperties {

	WebDriver driver; // Initialize the WebDriver
	JavascriptExecutor js;
	Screenshot ss;

	@FindBy(xpath = "//a[@id=\"rentheading\"]")
	WebElement rent;
	@FindBy(xpath = "//a[text()='Owner Properties']/parent::li")
	WebElement OwnerProperties;
	@FindBy(xpath = "//input[@class=\"auto-suggest__input topCityLocality\"]")
	WebElement AddMore;
	@FindBy(xpath = "//div[@class=\"auto-suggest__tag-close\"]")
	WebElement Cross;
	@FindBy(xpath = "//div[text()='Locations']/following-sibling::div/child::span[text()='chennai']")
	WebElement chennai;
	@FindBy(xpath = "//div[@style=\"bottom: 4px;\" and text()=\"Done\"]")
	WebElement Done;

	public HomePage_OwnerProperties(WebDriver driver) {
		this.driver = driver;
		js = (JavascriptExecutor) driver;
		PageFactory.initElements(driver, this);
		ss = new Screenshot(driver);
	}

	public void clickRent() throws AWTException, InterruptedException {

		// Store the current window handle
		String originalWindow = driver.getWindowHandle();
		new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.numberOfWindowsToBe(1));

		// Switch to the new window
		for (String windowHandle : driver.getWindowHandles()) {
			if (!windowHandle.equals(originalWindow)) {
				driver.switchTo().window(windowHandle);
				break;
			}
		}
		rent.click();
		Thread.sleep(2000); // Close the driver after a short delay to see the result
		Robot robot = new Robot();
		robot.mouseMove(190, 300); // Move the mouse to the specified coordinates
		Thread.sleep(3000);

		// Simulate a mouse click to focus the comment input field

		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); // Press left mouse button

		robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK); // Release left mouse button

		Thread.sleep(2000);

		originalWindow = driver.getWindowHandle();   // Window handling Using For Go to Starting Page
		for (String windowHandle : driver.getWindowHandles()) {
			if (!windowHandle.equals(originalWindow)) {
				driver.switchTo().window(windowHandle);
				break;
			}
		}
		Thread.sleep(3000);
		AddMore.click();
		Thread.sleep(3000);
		Cross.click();
		// AddMore.click();
		AddMore.sendKeys("Chennai");
		//Thread.sleep(3000);

		robot.mouseMove(100, 300);
		Thread.sleep(3000);
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		//Thread.sleep(2000);
		// chennai.click();
		Thread.sleep(5000);
		Done.click();
		js.executeScript("window.scrollBy(0,500)");  // JavaScript Using for Scrolling The Page 
		Thread.sleep(5000);
		js.executeScript("window.scrollBy(0,-500)");  // JavaScript Using for Scrolling The Page 
		Thread.sleep(3000);

		Robot robot1 = new Robot();
		robot1.mouseMove(150, 150);
		Thread.sleep(3000);
		robot1.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		robot1.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		Thread.sleep(3000);
		
		robot.mouseMove(539,260);
		Thread.sleep(3000);
		robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
		robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
		
		ss.captureScreenshot("TestCase1");                  // Test Case-1 Screenshot Capturing
	
	}
}
